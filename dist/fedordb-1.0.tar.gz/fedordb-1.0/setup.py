from setuptools import setup, find_packages
from os.path import join, dirname

setup(
    name = "fedordb",
    version = "1.0",
    author = "Fedor Avdeev",
    author_email = "f.avdeev@list.ru",
    packages = find_packages(),  
)